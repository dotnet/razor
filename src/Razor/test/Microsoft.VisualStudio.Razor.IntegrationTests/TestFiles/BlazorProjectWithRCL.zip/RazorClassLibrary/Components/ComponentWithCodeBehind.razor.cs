namespace MyCoolNamespace;

public partial class ComponentWithCodeBehind
{
}